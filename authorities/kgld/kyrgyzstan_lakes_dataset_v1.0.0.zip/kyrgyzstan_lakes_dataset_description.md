# Kyrgyzstan Lakes Dataset — v1.0.0

## Scope

Kyrgyzstan Lakes Dataset (KGLD) is a curated evidence dataset for lakes of Kyrgyzstan. It is not presented as an exhaustive
remote-sensing polygon inventory. Its purpose is to make named-lake facts, conflicting morphometric
traditions, government catalog identifiers, glacial-lake dynamics and source provenance reproducible.

Version `1.0.0` includes morphometry, classifications, inventory statistics, aggregate
statistics, glacial-lake events, dated observations, study-local ephemeral features, representative
point geometry, source lineage, explicit conflict decisions and a source-level rights/reuse audit.

## Evidence model

A lake entity is distinct from a measurement. Competing measurements remain as separate rows.
A selected reference is a curation decision, not deletion of alternatives.

The public-release audit adds a second decision: **public-reference eligibility**. A value can remain
the best available measurement for a comparability group while still being withheld from the
simplified public table if it is too dynamic, definition-dependent, context-specific or unresolved.

## Public flat view

`data/kyrgyzstan_lake_reference_public.csv` is generated from the audited selected-reference set. It carries
source IDs, confidence and audit status beside each exposed core value. Blank individual variables are intentional when the v1.0 release audit withholds a selected measurement. Entities with no audited public core value are omitted from this simplified view and remain available in `data/kyrgyzstan_lakes.csv` and the full evidence tables.

The simplified public reference contains **63 lake entities** from the **73-entity** master registry.

All **129** selected reference measurements were audited:
- **119** are eligible for the simplified public view;
- **10** are retained only in the full evidence layer.

Ala-Kul maximum depth is intentionally withheld from the simplified table because the modern
peer-reviewed ~70 m value conflicts sharply with the FAO 4.5 m tradition. Both values remain
traceable in the measurement and conflict tables.

## Glacial-lake dynamics

KGLD includes separate event and observation layers. The event table records documented
outburst/drainage episodes, while the observation table stores dated states and changes.
Study-local ephemeral supraglacial lakes are assigned stable feature IDs without being promoted
to permanent geographic lake entities.

Current dynamics coverage includes **11 events**, **26 observations** and **9 study-local features**.

## Geographic data

`data/kyrgyzstan_lakes.geojson` contains **8 source-traceable representative WGS84 points**. It is a point
reference layer, not a lake-polygon inventory. Dynamic polygon products should be observation-dated
and carry sensor, method, mapping threshold and explicit geometry-license provenance.

## Rights and reuse

KGLD-original schema, identifiers, documentation, curation decisions, source-lineage organization
and original database organization are released under **CC BY 4.0**. This does not relicense
third-party publications, databases, imagery, maps, source tables or figures.

See `kyrgyzstan_lakes_rights_and_reuse.md` and `metadata/kyrgyzstan_lake_rights_matrix.csv`.

## Release status

This package is the stable **KGLD v1.0.0** release prepared for Zenodo publication.
