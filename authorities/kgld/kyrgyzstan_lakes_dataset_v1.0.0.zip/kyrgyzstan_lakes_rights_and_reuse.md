# KGLD rights and reuse statement

KGLD contains original curation, schema, documentation, identifiers, source-linkage decisions and
derived organizational work, alongside individual factual claims extracted from cited third-party
sources.

## Planned KGLD license

The public v1.0.0 license for **KGLD-original curation, schema, documentation and database
organization** is **Creative Commons Attribution 4.0 International (CC BY 4.0)**.

This license does **not** grant rights that the KGLD curator does not hold in third-party publications,
databases, maps, photographs, figures, tables or other source material.

## Source-derived facts

KGLD does not bundle source PDFs, copied tables, figures, photographs or third-party lake polygons.
It stores compact factual measurements, classifications, event observations and source locators.

Some sources have explicit open licenses (for example CC BY or CC0). Others are copyrighted,
non-commercially licensed, or have unclear reuse terms. `metadata/kyrgyzstan_lake_rights_matrix.csv` records the
conservative handling rule for every registered source.

Particular caution applies to:
- National Statistical Committee website materials, which state CC BY-NC-SA 4.0 terms;
- FAO material whose applicable reuse policy may depend on the specific publication/database;
- ILEC World Lake Database material, which displays copyright but no open data license located in this audit;
- Ramsar/RSIS and Kyrgyz government publications where an explicit open reuse license was not established.

For these sources KGLD uses **citation + individual factual claims only** and does not reproduce
source tables or creative expression.

This is a data-curation rights statement, not legal advice. A final public release should retain
source attribution and this third-party-rights notice.


## Final v1.0 licensing decision

For the first public release, Zenodo should be set to **Creative Commons
Attribution 4.0 International (CC BY 4.0)**. This is the license for KGLD's
own curation and database organization. Third-party source rights remain
excluded as described above and in `metadata/kyrgyzstan_lake_rights_matrix.csv`.
