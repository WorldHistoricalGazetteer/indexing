# Kyrgyzstan Lakes Dataset — file naming convention

Version: 1.0.0

## Rule

All content-specific public files use a self-describing `kyrgyzstan_...` namespace.

Examples:
- `kyrgyzstan_lakes.csv`
- `kyrgyzstan_lake_measurements.csv`
- `kyrgyzstan_glacial_lake_events.csv`
- `kyrgyzstan_lake_sources.csv`

This makes files understandable when downloaded individually from Zenodo or reused outside the
original folder structure.

## Standard filenames retained

The following conventional machine/project filenames remain unchanged because external tools and
repository users expect them:

- `README.md`
- `LICENSE.txt`
- `CITATION.cff`
- `datapackage.json`

## Naming principles

1. lowercase ASCII filenames;
2. underscore-separated words;
3. prefix with `kyrgyzstan_`;
4. use `lake_` for lake-specific resources and `lakes` for the master entity/GIS layer;
5. include `glacial_lake_` where the resource is specifically about glacial-lake events;
6. include the release version only in package/workbook filenames, not in reusable CSV/GeoJSON names.
