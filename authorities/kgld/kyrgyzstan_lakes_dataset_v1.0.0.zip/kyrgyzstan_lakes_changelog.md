# Changelog

## 1.0.0 — 2026-08-30

- Added embedded Frictionless Table Schemas, primary/foreign keys, resource hashes/bytes and a machine-readable validation report.
- Normalized range-valued public/full reference morphometry into scalar/minimum/maximum numeric columns.

- Final release cleanup: simplified public reference now contains only entities with at least one audited public core value; operator-only Zenodo instructions and the recursive bundle entry were removed from the public file manifest.

- Standardized public filenames under the `kyrgyzstan_...` namespace for self-describing Zenodo downloads.

- Published first stable KGLD release package.
- Fixed creator metadata as Ethan Hamilton.
- Fixed release date as 2026-08-30.
- Completed selected-reference audit: 129 selected measurements reviewed, 119 public eligible, 10 withheld.
- Completed rights/reuse audit for all 37 registered sources.
- Added final public reference layer, rights matrix, event/observation model and source-lineage tables.
- Confirmed direct official Naryn MCHS catalog measurements.
- Finalized CC BY 4.0 licensing for KGLD-original rights with explicit third-party exclusions.
- Final package intentionally contains no pre-existing DOI; Zenodo will mint the DOI on publication.
- Corrected Sary-Chelek source S0007 title to the title registered for DOI 10.1017/qua.2019.21.
- Withheld Ala-Kul maximum depth from the simplified public reference because the 70 m vs 4.5 m conflict remains unresolved.
- Removed stale RC/dev release labels and repaired `datapackage.json` so every declared resource exists in the release.

## 1.0.0-rc1 — 2026-08-30

- Completed release-candidate selected-reference audit: 129 selected values reviewed.
- Generated `data/kyrgyzstan_lake_reference_public.csv` with 120 eligible references and 9 held values.
- Added `metadata/kyrgyzstan_lake_rights_matrix.csv` covering all 37 registered sources.
- Added `kyrgyzstan_lakes_rights_and_reuse.md` with third-party-rights exclusions.
- Added `curation/kyrgyzstan_lake_reference_audit.csv` and `curation/release_blockers.csv`.
- Directly re-verified the Naryn MCHS catalog table and upgraded seven Naryn measurements to `high / verified`.
- Withheld undated dynamic Kel-Suu area/volume, disputed Sary-Chelek maximum depth, definition-dependent Issyk-Kul measures and low-confidence Kulun volume from the public flat reference.
- Shifted remaining blockers from data modelling to creator/license/DOI publication closure.

## 0.5.0-dev — 2026-08-30

- Added `data/kyrgyzstan_glacial_lake_events.csv` with 11 documented events.
- Added `data/kyrgyzstan_lake_observations.csv` with 26 dated observations.
- Added `data/kyrgyzstan_lake_study_features.csv` with 9 stable IDs for source-local ephemeral features.
- Added Kashkasuu, Jeruy, Karateke and Toguz-Bulak as named KGLD lake entities.
- Added detailed 2008 western Zyndan growth/outburst time series and source-backed coordinate.
- Added Toguz-Bulak 2019 moraine-breach event and pre/post state.
- Added selected 2017–2018 Southern Inylchek individual/simultaneous drainage events.
- Added 2013–2016 Issyk-Kul Basin seasonal inventory and 2019 Kyrgyz/Teskey regional inventory.
- Added regional dynamics aggregate statistics for variability, emergence, disappearance and short-lived lakes.
- Expanded source-lineage model to connect the 2018 Teskey synthesis to the detailed 2010 western Zyndan case and the 2022 inventory to the 2018 regional work.

## 0.4.0-dev — 2026-08-30

- Shifted project focus from entity-count growth to publication/source-lineage quality.
- Expanded to 69 entities, 166 measurements and 31 registered sources.
- Added `data/kyrgyzstan_lake_aggregate_statistics.csv`.
- Added `metadata/kyrgyzstan_lake_source_lineage.csv`.
- Added `curation/article_correction_recommendations.csv`.
- Traced the 84.3% elevation claim from Usubaliev & Erokhin (2007) to Zhukov & Stavisskiy (1975) and corrected its scope.
- Resolved Main Kulun to 3.25 km² / 2856 m / 91 m and separated Main, Middle and Small Kulun.
- Moved the FAO 730 ha / Kara-Suu Kulun row to a separate unresolved inventory entity.
- Added a traceable 278 km² secondary Son-Kul tradition from KRSU 2021.
- Added nominal, explicitly non-current Kel-Suu 4.5 km² / 0.338 km³ reference morphometry.
- Increased representative GIS point layer to 7 features.
- Added `kyrgyzstan_lakes_dataset_description.md`, Zenodo metadata draft and Zenodo release checklist.
- Replaced assumed development citation creator with explicit pre-publication placeholders.

## 0.3.0-dev — 2026-08-30

- Expanded to 66 lake/lake-complex entities.
- Added full MCHS Issyk-Kul Table 5.7 crosswalk and four Naryn official hazard-catalog records.
- Added government catalog IDs, MCHS lake types and hazard categories.
- Added Ramsar coordinates for Issyk-Kul, Son-Kol and Chatyr-Kul.
- Added detailed Ramsar Son-Kol morphometry and its 13.2 m vs 22 m depth conflict.
- Added GNS-referenced Kel-Suu coordinate/elevation.
- Added peer-reviewed Petrov Lake 3741 m / 2.9 km study-period values.
- Documented duplicate GeoNames Kulun entities and withheld a GIS point.
- Added `data/kyrgyzstan_lakes.geojson` and `kyrgyzstan_lakes_gis.md`.
- Expanded conflict register to 15 cases.

## 0.2.0-dev — 2026-08-30

- Expanded from 11 to 29 lake entities.
- Expanded to 102 source-traceable measurements and 14 sources.
- Added modern peer-reviewed Ala-Kul and Sary-Chelek morphometry.
- Added FAO Table 4/Annex 2 named-lake records.
- Added Adygine Lakes 1–3 with observation-specific area/depth/volume time series.
- Split ambiguous Merzbacher record into Lower and Upper research entities while preserving the legacy ID.
- Added the 2024 national Sentinel-2 glacial-lake inventory (2,592 lakes; 77.6 km²) as a separate population from legacy all-lake statistics.
- Added `curation/kyrgyzstan_lake_conflict_register.csv` with 10 explicit discrepancies/non-comparability cases.
- Promoted major article mismatches (Ala-Kul, Sary-Chelek, Kulun, Merzbacher) to the audit queue.

## 0.1.0-dev — 2026-08-30

- Established KGLD schema version 1.0.0.
- Added 11 seed lake entities from the working Kyrgyzstan lake guide.
- Added official national statistics for 1,923 lakes / 6,836 km² and areas of the three largest lakes.
- Added audited ILEC morphometry for Issyk-Kul.
- Added Petrov Lake 2006 morphometry and historical area series from Janský et al. (2009).
- Added explicit reference-decision log and controlled vocabularies.
- Added article-claim curation queue, including high-priority conflicts requiring source resolution.
