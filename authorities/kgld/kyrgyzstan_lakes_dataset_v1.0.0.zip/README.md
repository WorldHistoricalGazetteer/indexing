# Kyrgyzstan Lakes Dataset

**Version:** `1.0.0`  
**Schema version:** `1.0.0`  
**Release date:** 2026-08-30  
**Creator:** Ethan Hamilton

Kyrgyzstan Lakes Dataset (KGLD) is a curated, source-traceable reference dataset for named and research-documented lakes of
Kyrgyzstan. It separates stable lake entities from published measurements, inventories, dated
observations, drainage/outburst events, source-lineage relations and study-local ephemeral features.

## Release scale

- **73** lake / lake-complex / unresolved-inventory entities
- **166** morphometric measurement records
- **11** documented glacial-lake drainage/outburst events
- **26** dated lake observations
- **9** study-local ephemeral features
- **37** registered sources
- **199** source-backed classifications
- **5** inventory records
- **12** scoped aggregate statistics
- **9** source-lineage relations
- **8** representative GIS points

## Audited public reference layer

All 129 selected reference measurements were reviewed for the v1.0.0 release.

- **119** are eligible for the simplified public reference layer.
- **10** are withheld from that flat view because they are undated dynamic values, context-specific
  survey values, scenario/potential values, scale/definition dependent, or still materially disputed.
- **63** lake entities appear in the simplified public table because they have at least one audited public core value; the master registry remains **73** entities.

The withheld measurements remain in `data/kyrgyzstan_lake_measurements.csv`; no evidence was deleted.

For simple reuse, start with the **63-row** simplified reference table:

`data/kyrgyzstan_lake_reference_public.csv`

For research, reconciliation or provenance work, use the full evidence tables.

## Glacial-lake dynamics

KGLD models fast-changing glacial lakes with dated observations and event records instead of one
timeless area value. The initial event layer covers Western Zyndan, Kashkasuu, Jeruy, Karateke,
Toguz-Bulak and selected Southern Inylchek supraglacial drainage events.

## GIS

`data/kyrgyzstan_lakes.geojson` contains source-traceable representative WGS84 points. It is not a shoreline
polygon inventory. Dynamic polygons should be released separately with observation date, sensor,
method, mapping threshold and explicit geometry license.

## Rights and license

KGLD-original schema, identifiers, curation, documentation, source-lineage organization and database
organization are released under **CC BY 4.0**.

This does not relicense third-party publications, databases, maps, imagery, tables or figures.
See `kyrgyzstan_lakes_rights_and_reuse.md` and `metadata/kyrgyzstan_lake_rights_matrix.csv`.

## Citation

Citation metadata is provided in `CITATION.cff`.

This local release package does not contain a DOI because there is no pre-existing DOI. Zenodo will
assign the dataset DOI automatically when this exact release is published there.

Project page: https://kyrgyzstanplanner.com/lakes-of-kyrgyzstan/


### v1.0 final audit note

Ala-Kul maximum depth is withheld from `data/kyrgyzstan_lake_reference_public.csv` because the modern peer-reviewed ~70 m value conflicts with the FAO 4.5 m value. Both remain in the full measurement/conflict evidence layer.

## File naming

Public dataset resources use the `kyrgyzstan_...` namespace so that files remain self-describing
when downloaded individually from Zenodo. See `kyrgyzstan_lakes_file_naming.md`.

### Primary download files

- `data/kyrgyzstan_lake_reference_public.csv` — audited simplified reference table.
- `data/kyrgyzstan_lake_measurements.csv` — full numeric evidence layer.
- `data/kyrgyzstan_glacial_lake_events.csv` — documented GLOF/drainage events.
- `data/kyrgyzstan_lakes.geojson` — representative GIS points.
- `metadata/kyrgyzstan_lake_sources.csv` — source registry.
- `kyrgyzstan_lakes_dataset_v1.0.0_workbook.xlsx` — human-readable workbook.

## Machine-readable validation

`datapackage.json` is a mixed Data Package descriptor: every CSV resource is declared as a
`tabular-data-resource` with an embedded Table Schema, primary key where applicable, and key
foreign-key relations. The GeoJSON resource remains a standard non-tabular data resource.

Release-level validation outputs:
- `metadata/kyrgyzstan_lake_validation_report.json`
- `metadata/kyrgyzstan_lake_resource_inventory.csv`

The validation report checks schema/header alignment, field types and required constraints,
primary-key uniqueness, declared foreign keys, list-valued source/feature references, public-reference
semantics, GIS coordinates and consistency across CFF/Zenodo/Data Package/release metadata.
