# KGLD GIS layer

**Release:** 1.0.0  
**Date:** 2026-08-30

`data/kyrgyzstan_lakes.geojson` contains source-traceable **representative WGS84 points**, not lake polygons.

The v1.0.0 layer contains **8 source-traceable representative WGS84 points**. Coordinates enter this layer only when a registered source
supports the point and the KGLD lake identity is sufficiently resolved.

## Inclusion rules

A point is included only when:
1. the coordinate source is registered;
2. the point can be tied to a stable KGLD entity;
3. the coordinate role/method is documented;
4. known identity ambiguity does not make the point misleading.

Main Kulun is included after identity reconciliation. A second nearby same-name GeoNames point
remains unassigned rather than being guessed into the Main/Middle/Small Kulun system.

Western Zyndan is included using the coordinate published in the detailed 2010 event study.

## Why no polygons in v1.0.0

For glacial, seasonal and strongly variable lakes, shoreline geometry is observation-specific.
Redistributing third-party polygons may also introduce license incompatibilities.

A future KGLD polygon product should therefore be a separate, dated layer such as
`lake_extents_2024.geojson` and record:
- acquisition date;
- sensor/source imagery;
- mapping method;
- minimum mapping unit / spatial resolution;
- geometry license and provenance.

A modern shoreline should never be silently represented as timeless lake geometry.
